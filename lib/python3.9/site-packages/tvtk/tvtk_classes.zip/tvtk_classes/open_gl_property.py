# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.property import Property


class OpenGLProperty(Property):
    """
    OpenGLProperty - open_gl property
    
    Superclass: Property
    
    OpenGLProperty is a concrete implementation of the abstract class
    Property. OpenGLProperty interfaces to the open_gl rendering
    library.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLProperty, obj, update, **traits)
    
    _updateable_traits_ = \
    (('backface_culling', 'GetBackfaceCulling'), ('edge_visibility',
    'GetEdgeVisibility'), ('frontface_culling', 'GetFrontfaceCulling'),
    ('lighting', 'GetLighting'), ('render_lines_as_tubes',
    'GetRenderLinesAsTubes'), ('render_points_as_spheres',
    'GetRenderPointsAsSpheres'), ('shading', 'GetShading'),
    ('show_textures_on_backface', 'GetShowTexturesOnBackface'),
    ('vertex_visibility', 'GetVertexVisibility'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('interpolation', 'GetInterpolation'), ('representation',
    'GetRepresentation'), ('ambient', 'GetAmbient'), ('ambient_color',
    'GetAmbientColor'), ('anisotropy', 'GetAnisotropy'),
    ('anisotropy_rotation', 'GetAnisotropyRotation'), ('base_ior',
    'GetBaseIOR'), ('coat_color', 'GetCoatColor'), ('coat_ior',
    'GetCoatIOR'), ('coat_normal_scale', 'GetCoatNormalScale'),
    ('coat_roughness', 'GetCoatRoughness'), ('coat_strength',
    'GetCoatStrength'), ('color', 'GetColor'), ('diffuse', 'GetDiffuse'),
    ('diffuse_color', 'GetDiffuseColor'), ('edge_color', 'GetEdgeColor'),
    ('edge_tint', 'GetEdgeTint'), ('emissive_factor',
    'GetEmissiveFactor'), ('line_stipple_pattern',
    'GetLineStipplePattern'), ('line_stipple_repeat_factor',
    'GetLineStippleRepeatFactor'), ('line_width', 'GetLineWidth'),
    ('material_name', 'GetMaterialName'), ('metallic', 'GetMetallic'),
    ('normal_scale', 'GetNormalScale'), ('occlusion_strength',
    'GetOcclusionStrength'), ('opacity', 'GetOpacity'), ('point_size',
    'GetPointSize'), ('roughness', 'GetRoughness'), ('selection_color',
    'GetSelectionColor'), ('selection_line_width',
    'GetSelectionLineWidth'), ('selection_point_size',
    'GetSelectionPointSize'), ('specular', 'GetSpecular'),
    ('specular_color', 'GetSpecularColor'), ('specular_power',
    'GetSpecularPower'), ('vertex_color', 'GetVertexColor'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['backface_culling', 'debug', 'edge_visibility', 'frontface_culling',
    'global_warning_display', 'lighting', 'render_lines_as_tubes',
    'render_points_as_spheres', 'shading', 'show_textures_on_backface',
    'vertex_visibility', 'interpolation', 'representation', 'ambient',
    'ambient_color', 'anisotropy', 'anisotropy_rotation', 'base_ior',
    'coat_color', 'coat_ior', 'coat_normal_scale', 'coat_roughness',
    'coat_strength', 'color', 'diffuse', 'diffuse_color', 'edge_color',
    'edge_tint', 'emissive_factor', 'line_stipple_pattern',
    'line_stipple_repeat_factor', 'line_width', 'material_name',
    'metallic', 'normal_scale', 'occlusion_strength', 'opacity',
    'point_size', 'roughness', 'selection_color', 'selection_line_width',
    'selection_point_size', 'specular', 'specular_color',
    'specular_power', 'vertex_color'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLProperty, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLProperty properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['backface_culling', 'edge_visibility', 'frontface_culling',
            'lighting', 'render_lines_as_tubes', 'render_points_as_spheres',
            'shading', 'show_textures_on_backface', 'vertex_visibility'],
            ['interpolation', 'representation'], ['ambient', 'ambient_color',
            'anisotropy', 'anisotropy_rotation', 'base_ior', 'coat_color',
            'coat_ior', 'coat_normal_scale', 'coat_roughness', 'coat_strength',
            'color', 'diffuse', 'diffuse_color', 'edge_color', 'edge_tint',
            'emissive_factor', 'line_stipple_pattern',
            'line_stipple_repeat_factor', 'line_width', 'material_name',
            'metallic', 'normal_scale', 'occlusion_strength', 'opacity',
            'point_size', 'roughness', 'selection_color', 'selection_line_width',
            'selection_point_size', 'specular', 'specular_color',
            'specular_power', 'vertex_color']),
            title='Edit OpenGLProperty properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLProperty properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

