# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class WebGLDataSet(Object):
    """
    WebGLDataSet - WebGLDataSet represent vertices, lines,
    polygons, and triangles.
    
    Superclass: Object
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkWebGLDataSet, obj, update, **traits)
    
    def _get_binary_data(self):
        return self._vtk_obj.GetBinaryData()
    binary_data = traits.Property(_get_binary_data, desc=\
        """
        
        """
    )

    def _get_binary_size(self):
        return self._vtk_obj.GetBinarySize()
    binary_size = traits.Property(_get_binary_size, desc=\
        """
        
        """
    )

    def _get_md5(self):
        return self._vtk_obj.GetMD5()
    md5 = traits.Property(_get_md5, desc=\
        """
        
        """
    )

    def generate_binary_data(self):
        """
        generate_binary_data(self) -> None
        C++: void generate_binary_data()"""
        ret = self._vtk_obj.GenerateBinaryData()
        return ret
        

    def has_changed(self):
        """
        has_changed(self) -> bool
        C++: bool has_changed()"""
        ret = self._vtk_obj.HasChanged()
        return ret
        

    def set_colors(self, *args):
        """
        set_colors(self, c:[int, ...]) -> None
        C++: void set_colors(unsigned char *c)"""
        ret = self._wrap_call(self._vtk_obj.SetColors, *args)
        return ret

    def set_indexes(self, *args):
        """
        set_indexes(self, i:[int, ...], size:int) -> None
        C++: void set_indexes(short *i, int size)"""
        ret = self._wrap_call(self._vtk_obj.SetIndexes, *args)
        return ret

    def set_matrix(self, *args):
        """
        set_matrix(self, m:[float, ...]) -> None
        C++: void set_matrix(float *m)"""
        ret = self._wrap_call(self._vtk_obj.SetMatrix, *args)
        return ret

    def set_normals(self, *args):
        """
        set_normals(self, n:[float, ...]) -> None
        C++: void set_normals(float *n)"""
        ret = self._wrap_call(self._vtk_obj.SetNormals, *args)
        return ret

    def set_points(self, *args):
        """
        set_points(self, p:[float, ...], size:int) -> None
        C++: void set_points(float *p, int size)"""
        ret = self._wrap_call(self._vtk_obj.SetPoints, *args)
        return ret

    def set_t_coords(self, *args):
        """
        set_t_coords(self, t:[float, ...]) -> None
        C++: void set_t_coords(float *t)"""
        ret = self._wrap_call(self._vtk_obj.SetTCoords, *args)
        return ret

    def set_type(self, *args):
        """
        set_type(self, t:WebGLObjectTypes) -> None
        C++: void set_type(WebGLObjectTypes t)"""
        ret = self._wrap_call(self._vtk_obj.SetType, *args)
        return ret

    def set_vertices(self, *args):
        """
        set_vertices(self, v:[float, ...], size:int) -> None
        C++: void set_vertices(float *v, int size)"""
        ret = self._wrap_call(self._vtk_obj.SetVertices, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(WebGLDataSet, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit WebGLDataSet properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], []),
            title='Edit WebGLDataSet properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit WebGLDataSet properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

